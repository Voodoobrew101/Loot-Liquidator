-- Native Options > AddOns configuration. Every appearance preference applies
-- to BetterBags, Blizzard bags, banks and tooltips simultaneously.
local ADDON, LL = ...
local COLORS={A={1,.84,.18},V={.85,.85,.85},D={.72,.36,1},
    M={.20,.88,.36},P={.25,.75,1},S={1,.55,.21},C={1,.64,.22},Q={1,.53,.18},T={.40,.94,.84}}
local NAMES={A="Auction",V="Vendor",D="Disenchant",M="Mill",P="Prospect",
    S="Smelt",Q="Insufficient Data",T="Transmog"}
local ORDER={"A","V","D","M","P","S","T","Q"}
local POSITIONS={"TOPLEFT","TOP","TOPRIGHT","LEFT","CENTER","RIGHT","BOTTOMLEFT","BOTTOM","BOTTOMRIGHT"}
function LL:GetBadgeColor(action)
    local custom=self.db and self.db.appearance and self.db.appearance.colors
    return (custom and custom[action]) or COLORS[action] or {1,1,1}
end
function LL:MarkupColor(action)
    local c=self:GetBadgeColor(action)
    return ("|cff%02x%02x%02x"):format(math.floor(c[1]*255+.5),
        math.floor(c[2]*255+.5),math.floor(c[3]*255+.5))
end
function LL:UpdateAllAppearance()
    if self.Invalidate then self:Invalidate() end
    if self.QueueBlizzardBagRefresh then self:QueueBlizzardBagRefresh() end
    if self.RefreshPreviews then self:RefreshPreviews() end
    if self.badgeSettingsPanel and self.badgeSettingsPanel.RefreshVisibility then
        self.badgeSettingsPanel:RefreshVisibility()
    end
    -- Refresh currently visible WoW tooltip only when the host exposes a
    -- supported refresh method; never simulate another item hover.
    if GameTooltip and GameTooltip.IsShown and GameTooltip:IsShown()
        and type(GameTooltip.RefreshData)=="function" then
        pcall(GameTooltip.RefreshData,GameTooltip)
    end
end
local function Section(layout,title)
    if layout and layout.AddInitializer and CreateSettingsListSectionHeaderInitializer then
        layout:AddInitializer(CreateSettingsListSectionHeaderInitializer(title))
    end
end
local function Checkbox(category,key,name,description,default)
    local d=LL.db
    local setting=Settings.RegisterAddOnSetting(category,"LootLiquidator_"..key,key,d,
        "boolean",name,default)
    if setting.SetValueChangedCallback then
        setting:SetValueChangedCallback(function() LL:UpdateAllAppearance() end)
    end
    Settings.CreateCheckbox(category,setting,description or "")
end
local function Dropdown(category,key,title,description,options,default)
    local setting=Settings.RegisterAddOnSetting(category,"LootLiquidator_"..key,
        key,LL.db,"number",title,default)
    if setting.SetValueChangedCallback then
        setting:SetValueChangedCallback(function() LL:UpdateAllAppearance() end)
    end
    local function Values()
        local out=Settings.CreateControlTextContainer()
        for _,o in ipairs(options) do out:Add(o[1],o[2],o[3] or "") end
        return out:GetData()
    end
    Settings.CreateDropdown(category,setting,Values,description or "")
end
-- This is a live list, read afresh when Blizzard displays the dropdown.
-- All choices are read-only in TSM. Selecting an operation here affects
-- Loot Liquidator's *estimate*, not TSM's group assignments/posting UI.
local function TSMDropdown(category,key,title)
    local setting=Settings.RegisterAddOnSetting(category,"LootLiquidator_"..key,
        key,LL.db,"string",title,key=="tsmFallbackOperation" and "@none" or "@assigned")
    if setting.SetValueChangedCallback then
        setting:SetValueChangedCallback(function() LL:UpdateAllAppearance() end)
    end
    local function Values()
        local out=Settings.CreateControlTextContainer()
        if key=="tsmFallbackOperation" then
            out:Add("@none","No override — show unknown pricing","Only used when TSM has no assigned operation")
        else
            out:Add("@assigned","Use item's assigned TSM operation",
                "Uses TSM grouping and its first auctioning operation")
        end
        local names,reason=LL:GetAuctionOperationNames()
        for _,name in ipairs(names) do
            out:Add(name,name,"Preview prices using this operation; assign in TSM to actually post with it")
        end
        return out:GetData()
    end
    Settings.CreateDropdown(category,setting,Values,
        "Read-only price simulation. To actually post with this operation, assign it to the item in TSM.")
end
local function Slider(category,key,title,description,lower,upper,step,default)
    local setting=Settings.RegisterAddOnSetting(category,"LootLiquidator_"..key,
        key,LL.db,"number",title,default)
    if setting.SetValueChangedCallback then
        setting:SetValueChangedCallback(function() LL:UpdateAllAppearance() end)
    end
    local options=Settings.CreateSliderOptions(lower,upper,step)
    if options.SetLabelFormatter and MinimalSliderWithSteppersMixin then
        options:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right)
    end
    Settings.CreateSlider(category,setting,options,description or "")
end
local function ExplainOnHover(control,title,description)
    control:SetScript("OnEnter",function(self)
        if GameTooltip then
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            GameTooltip:SetText(title,1,1,1)
            GameTooltip:AddLine(description,.8,.8,.8,true)
            GameTooltip:Show()
        end
    end)
    control:SetScript("OnLeave",function() if GameTooltip then GameTooltip:Hide() end end)
end
local function SettingsButton(parent)
    return LL:CreateSettingsButton(parent)
end
local PreviewPanel
local function AppearancePanel()
    local panel=CreateFrame("Frame")
    local function title(str,x,y,object)
        local fs=panel:CreateFontString(nil,"ARTWORK",object or "GameFontNormal")
        fs:SetPoint("TOPLEFT",panel,"TOPLEFT",x,y)
        fs:SetText(str)
        return fs
    end
    title("One appearance profile for every bag and bank",16,-18,"GameFontHighlight")
    -- Global badge visibility belongs here; the General page only enables the addon.
    local badgeToggle=LL:CreateSettingsCheckbox(panel)
    badgeToggle:SetSize(23,23)
    badgeToggle:SetPoint("TOPLEFT",panel,"TOPLEFT",20,-42)
    panel.llVisibilityCheckboxes={showBadges=badgeToggle}
    local badgeLabel=panel:CreateFontString(nil,"ARTWORK","GameFontHighlight")
    badgeLabel:SetPoint("LEFT",badgeToggle,"RIGHT",6,0)
    badgeLabel:SetText("Show item badges")
    badgeToggle:SetScript("OnClick",function(self)
        LL.db.showBadges=self:GetChecked()==true
        LL:UpdateAllAppearance()
    end)
    panel:HookScript("OnShow",function()panel:RefreshVisibility()end)
    title("Where to show badges",20,-88)
    -- These checkboxes have moved from General; saved keys and the actual bag
    -- integrations are unchanged. Use Blizzard's real Settings check boxes.
    local surfaces={
        {key="showBlizzardBags",label="Blizzard bags & banks",x=20},
        {key="showBetterBags",label="BetterBags",x=264},
        {key="showGuildBank",label="Guild bank",x=424},
    }
    function panel:RefreshVisibility()
        for key,checkbox in pairs(self.llVisibilityCheckboxes) do
            checkbox:SetChecked(LL.db[key]~=false)
        end
    end
    for _,surface in ipairs(surfaces) do
        local cb=LL:CreateSettingsCheckbox(panel)
        panel.llVisibilityCheckboxes[surface.key]=cb
        cb:SetSize(23,23)
        cb:SetPoint("TOPLEFT",panel,"TOPLEFT",surface.x,-110)
        local label=panel:CreateFontString(nil,"ARTWORK","GameFontHighlight")
        label:SetPoint("LEFT",cb,"RIGHT",6,0)
        label:SetText(surface.label)
        cb:SetChecked(LL.db[surface.key]~=false)
        cb:SetScript("OnClick",function(self)
            LL.db[surface.key]=self:GetChecked()==true
            LL:UpdateAllAppearance()
        end)
        panel:HookScript("OnShow",function()cb:SetChecked(LL.db[surface.key]~=false)end)
    end
    title("Badge position",20,-149)
    local displayNames={TOPLEFT="Top left",TOP="Top center",TOPRIGHT="Top right",
        LEFT="Middle left",CENTER="Center",RIGHT="Middle right",
        BOTTOMLEFT="Bottom left",BOTTOM="Bottom center",BOTTOMRIGHT="Bottom right"}
    for i,pos in ipairs(POSITIONS) do
        local btn=SettingsButton(panel)
        btn:SetSize(118,24)
        btn:SetPoint("TOPLEFT",20+((i-1)%3)*130,-171-math.floor((i-1)/3)*27)
        ExplainOnHover(btn,"Badge position","Places the badge at this point on the item icon. Applies to every supported bag interface.")
        btn:SetText(displayNames[pos])
        btn:SetScript("OnClick",function()
            LL.db.appearance.position=pos
            LL:UpdateAllAppearance()
            if panel.RefreshPositionButtons then panel:RefreshPositionButtons() end
        end)
        panel.llPositionButtons=panel.llPositionButtons or {}
        panel.llPositionButtons[pos]=btn
    end
    function panel:RefreshPositionButtons()
        for pos,button in pairs(self.llPositionButtons or {}) do
            if button.SetSelected then
                button:SetSelected(LL.db.appearance.position == pos)
            end
        end
    end
    panel:HookScript("OnShow",function(self) self:RefreshPositionButtons() end)
    panel:RefreshPositionButtons()
    title("Badge font size",20,-254)
    local slider=LL:CreateSettingsCanvasSlider(panel,9,22,1,
        LL.db.appearance.fontSize or 14,function(num)
            if LL.db.appearance.fontSize~=num then
                LL.db.appearance.fontSize=num
                LL:UpdateAllAppearance()
            end
        end)
    slider:SetPoint("TOPLEFT",panel,"TOPLEFT",20,-277)
    ExplainOnHover(slider,"Badge font size","DISPLAY ONLY: The shared badge font size (9 to 22) for every supported bag interface.")
    ExplainOnHover(slider.slider,"Badge font size","DISPLAY ONLY: The shared badge font size (9 to 22) for every supported bag interface.")
    panel:HookScript("OnShow",function()
        slider:SetValue(LL.db.appearance.fontSize or 14)
    end)
    title("Colors (click to customize each action)",20,-320)
    for i,letter in ipairs(ORDER) do
        local row=math.floor((i-1)/2);local col=(i-1)%2
        local btn=SettingsButton(panel)
        btn:SetSize(174,26)
        btn:SetPoint("TOPLEFT",20+col*192,-344-row*31)
        local function update()
            local c=LL:GetBadgeColor(letter)
            btn:SetText(letter.."  "..NAMES[letter])
            local font=btn:GetFontString()
            if font then font:SetTextColor(c[1],c[2],c[3]) end
        end
        ExplainOnHover(btn,"Badge color: "..NAMES[letter],"DISPLAY ONLY: Change the displayed color of this badge everywhere. Gold recommendations do not change.")
        btn:SetScript("OnClick",function()
            if not ColorPickerFrame or not ColorPickerFrame.SetupColorPickerAndShow then return end
            local c=LL:GetBadgeColor(letter)
            local before={c[1],c[2],c[3]}
            ColorPickerFrame:SetupColorPickerAndShow({
                r=c[1],g=c[2],b=c[3],hasOpacity=false,
                swatchFunc=function()
                    local r,g,b=ColorPickerFrame:GetColorRGB()
                    LL.db.appearance.colors[letter]={r,g,b}
                    update();LL:UpdateAllAppearance()
                end,
                cancelFunc=function()
                    LL.db.appearance.colors[letter]=before
                    update();LL:UpdateAllAppearance()
                end,
            })
        end)
        update()
    end
    local hideUnknown=LL:CreateSettingsCheckbox(panel)
    hideUnknown:SetPoint("TOPLEFT",panel,"TOPLEFT",402,-435)
    hideUnknown:SetSize(25,25)
    hideUnknown:SetChecked(LL.db.showUnknownBadge~=false)
    local unknownLabel=panel:CreateFontString(nil,"ARTWORK","GameFontHighlight")
    unknownLabel:SetPoint("LEFT",hideUnknown,"RIGHT",3,0)
    unknownLabel:SetText("Show ?")
    ExplainOnHover(hideUnknown,"Show Insufficient Data badge",
        "Display only: Hide or show '?' without changing item recommendations.")
    hideUnknown:SetScript("OnClick",function(self)
        LL.db.showUnknownBadge=self:GetChecked()==true
        LL:UpdateAllAppearance()
    end)
    panel:HookScript("OnShow",function()
        hideUnknown:SetChecked(LL.db.showUnknownBadge~=false)
    end)
    -- Display-only badge policy belongs with badge appearance, not valuation.
    local soulbound=LL:CreateSettingsCheckbox(panel)
    soulbound:SetSize(24,24)
    soulbound:SetPoint("TOPLEFT",panel,"TOPLEFT",20,-473)
    soulbound:SetChecked(LL.db.showSoulboundVendorBadge==true)
    local boundLabel=panel:CreateFontString(nil,"ARTWORK","GameFontHighlight")
    boundLabel:SetPoint("LEFT",soulbound,"RIGHT",6,0)
    boundLabel:SetText("Show V on soulbound gear")
    ExplainOnHover(soulbound,"Bound equipment badges",
        "Display the Vendor badge on soulbound gear with no better available action.")
    soulbound:SetScript("OnClick",function(self)
        LL.db.showSoulboundVendorBadge=self:GetChecked()==true
        LL:UpdateAllAppearance()
    end)
    panel:HookScript("OnShow",function()
        soulbound:SetChecked(LL.db.showSoulboundVendorBadge==true)
    end)
    local preview=PreviewPanel()
    preview:SetParent(panel)
    preview:SetPoint("TOPLEFT",panel,"TOPLEFT",0,-510)
    preview:SetSize(560,82)
    return panel
end

-- Shared illustration uses the same LA:Paint and AppendRecommendationTooltip as
-- real bag buttons. Figures are EXAMPLES, never taken as live TSM quotes.
local previewPanels=setmetatable({}, {__mode="k"})
-- Preview-only example fixtures. Their output IDs are real materials, but
-- quantities and monetary values are ILLUSTRATIONS, never live market quotes.
-- Every example uses the normal tooltip material renderer; no second tooltip
-- implementation or dependency on TSM/ATT is needed to draw the examples.
local PREVIEW_ITEMS = {
    {name="Sample Mageroyal (62)",itemID=785,action="A",count=62,
        auction=20000,convert=16200,vendor=100,method="Mill",letter="M",inputCount=5,
        outputs={
            {id=39334,chance=1,expectedQuantity=3,minQuantity=2,maxQuantity=4,priceWeight=1},
            {id=43103,chance=.25,expectedQuantity=.5,minQuantity=1,maxQuantity=3,priceWeight=3},
        }},
    {name="Sample soulbound ring",itemID=272147,action="D",count=1,
        auction=nil,convert=480000,vendor=369500,method="Disenchant",letter="D",inputCount=1,
        outputs={{id=243605,expectedQuantity=1,priceWeight=1}}},
    {name="Sample Copper Ore (10)",itemID=2770,action="S",count=10,
        auction=35000,convert=47000,vendor=500,method="Smelt",letter="S",inputCount=10,
        outputs={{id=2840,expectedQuantity=10,minQuantity=10,maxQuantity=10,priceWeight=1}}},
}
local function SampleDecision(row)
    local options={{name=row.method,letter=row.letter,available=true,value=row.convert,
        confidence="illustrative",source="Illustrative values only",inputCount=row.inputCount}}
    -- The mock conversion total is per original item, while outputs are per
    -- processing batch. Allocate synthetic unit quotes so the breakdown adds
    -- back up to the quoted conversion value after the optional AH fee.
    local weightSum=0
    for _,material in ipairs(row.outputs or {}) do
        weightSum=weightSum+(material.expectedQuantity or 0)*(material.priceWeight or 1)
    end
    local outputs={}
    local fee=LL.AHFeeRate and LL:AHFeeRate() or .05
    if type(fee)~="number" or fee<0 or fee>=1 then fee=.05 end
    local unitBase=weightSum>0 and (row.convert or 0)*(row.inputCount or 1)
        / ((1-fee)*weightSum) or 0
    for _,material in ipairs(row.outputs or {}) do
        local price=unitBase*(material.priceWeight or 1)
        outputs[#outputs+1]={id=material.id,chance=material.chance,
            expectedQuantity=material.expectedQuantity,
            minQuantity=material.minQuantity,maxQuantity=material.maxQuantity,
            unitPrice=price,expectedValue=price*material.expectedQuantity,
            illustrative=true}
    end
    options[1].estimate={confidence="illustrative",inputCount=row.inputCount,
        note="Preview only: sample quantities and prices",materials=outputs}
    if row.itemID==2770 then
        -- Copper ore is BOTH smeltable and prospectable. The latter operates
        -- on two 5-ore batches in this ten-ore illustration. This fixture
        -- never calls TSM or alters measured/provisional Game Data.
        local gems={
            {id=774,chance=.5,expectedQuantity=.75},
            {id=818,chance=.5,expectedQuantity=.75},
            {id=1210,chance=.10,expectedQuantity=.15},
        }
        local prospectTotal=30000
        local prospectSum=0
        for _,m in ipairs(gems) do prospectSum=prospectSum+m.expectedQuantity end
        local unit=prospectTotal*5/((1-fee)*prospectSum)
        for _,m in ipairs(gems) do
            m.minQuantity=1;m.maxQuantity=2
            m.unitPrice=unit;m.expectedValue=unit*m.expectedQuantity
            m.illustrative=true
        end
        options[#options+1]={name="Prospect",letter="P",available=true,
            value=prospectTotal,inputCount=5,confidence="illustrative",
            estimate={confidence="illustrative",inputCount=5,
                note="Illustrative historical gem chances",materials=gems}}
    end
    return {action=row.action,method=row.method,conversion=options[1],
        conversionOptions=options,itemID=row.itemID,count=row.count,
        rawAuction=row.auction,netAuction=row.auction and row.auction*(1-fee) or 0,
        vendor=row.vendor,auctionEligible=row.auction~=nil,facts={name=row.name},
        isBound=row.auction==nil}
end
PreviewPanel=function()
    local panel=CreateFrame("Frame")
    panel:SetSize(560,90)
    local index=1
    local caption=panel:CreateFontString(nil,"ARTWORK","GameFontHighlightSmall")
    caption:SetPoint("TOPLEFT",panel,"TOPLEFT",20,-7)
    caption:SetText("Sample item — hover over the icon for a tooltip preview")
    local icon=CreateFrame("Button",nil,panel)
    icon:SetSize(46,46); icon:SetPoint("TOPLEFT",panel,"TOPLEFT",20,-28)
    local texture=icon:CreateTexture(nil,"BACKGROUND")
    texture:SetAllPoints(icon)
    texture:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    local name=panel:CreateFontString(nil,"ARTWORK","GameFontNormal")
    name:SetPoint("TOPLEFT",icon,"TOPRIGHT",16,-5)
    local indicator=panel:CreateFontString(nil,"ARTWORK","GameFontHighlightSmall")
    indicator:SetPoint("TOPLEFT",name,"BOTTOMLEFT",0,-8)
    local change=SettingsButton(panel)
    change:SetSize(155,25);change:SetPoint("TOPLEFT",panel,"TOPLEFT",337,-37)
    change:SetText("Next sample item")
    panel.refresh=function()
        if not LL.db then return end
        local row=PREVIEW_ITEMS[index]
        if C_Item and C_Item.GetItemIconByID then
            local textureID=C_Item.GetItemIconByID(row.itemID)
            if textureID then texture:SetTexture(textureID) end
        end
        name:SetText(row.name)
        indicator:SetText("Preview only | "..(LL.db.tooltipDetail==1 and "Minimal" or
            LL.db.tooltipDetail==3 and "Detailed" or "Summary").." | "..
            (LL.db.tooltipShowAfterAHCut~=false and "AH net" or "AH listing"))
        LL:Paint(icon,"preview:"..row.itemID,SampleDecision(row))
    end
    change:SetScript("OnClick",function()
        index=index%#PREVIEW_ITEMS+1
        panel.refresh()
    end)
    -- Dedicated preview tooltip: never ClearLines/SetOwner on the global
    -- GameTooltip used by bags, Pawn, TSM, and comparison tooltips.
    local previewTip
    icon:SetScript("OnEnter",function()
        if not LL.AppendRecommendationTooltip then return end
        if not previewTip then
            previewTip=CreateFrame("GameTooltip","LootLiquidatorPreviewTooltip",UIParent,"GameTooltipTemplate")
        end
        previewTip:SetOwner(icon,"ANCHOR_RIGHT")
        previewTip:ClearLines()
        previewTip:AddLine(PREVIEW_ITEMS[index].name,1,1,1)
        previewTip:AddLine("ILLUSTRATIVE prices, not live quotes",1,.7,.2)
        LL:AppendRecommendationTooltip(previewTip,SampleDecision(PREVIEW_ITEMS[index]))
        previewTip:Show()
    end)
    icon:SetScript("OnLeave",function() if previewTip then previewTip:Hide() end end)
    panel:HookScript("OnShow",function() panel.refresh() end)
    previewPanels[panel]=true
    return panel
end
function LL:RefreshPreviews()
    for panel in pairs(previewPanels) do if panel.refresh then panel.refresh() end end
end

-- A single hover-preview widget serves Badges & Colors AND Tooltips.
-- No duplicate, static 14-row rendering or 335px blank frame.
function LootLiquidator_InitTooltipPreview(panel)
    if panel.llInitialized then return end
    panel.llInitialized=true
    local preview=PreviewPanel()
    preview:SetParent(panel)
    preview:SetPoint("TOPLEFT",panel,"TOPLEFT",0,0)
    preview:SetSize(560,90)
    panel.llPreview=preview
end

-- Settings are grouped by user intent, not by the Lua module providing them.
-- Crucially each SavedVariables key is registered exactly once so existing
-- profiles and preferences survive moving a control to another page.
function LL:RegisterNativeSettings()
    if self.settingsCategory or not self.db or not Settings
        or not Settings.RegisterVerticalLayoutCategory then return end

    local general, generalLayout=Settings.RegisterVerticalLayoutCategory("Loot Liquidator  v"..tostring(self.version or "?"))
    Settings.RegisterAddOnCategory(general)
    self.settingsCategory=general
    Section(generalLayout,"General")
    Checkbox(general,"enabled","Enable Loot Liquidator",
        "Analyze items and recommend the most valuable available action.",true)
    Section(generalLayout,"Use the pages on the left for badge appearance, tooltips, pricing, and addon integrations.")

    local appearancePanel=AppearancePanel()
    local appearance=Settings.RegisterCanvasLayoutSubcategory(general,appearancePanel,"Badges & Colors")
    Settings.RegisterAddOnCategory(appearance)
    self.badgeSettingsPanel=appearancePanel
    -- Register the moved canvas controls for WoW's Defaults button and
    -- SavedVariables metadata WITHOUT creating a duplicate visible checkbox.
    -- Default/reset callbacks refresh the same native canvas checkboxes.
    for _,row in ipairs({
        {"showBadges","Show item badges"},
        {"showBlizzardBags","Blizzard bags and banks"},
        {"showBetterBags","BetterBags"},
        {"showGuildBank","Guild bank"},
    }) do
        local setting=Settings.RegisterAddOnSetting(appearance,
            "LootLiquidator_"..row[1],row[1],self.db,"boolean",row[2],true)
        if setting.SetValueChangedCallback then
            setting:SetValueChangedCallback(function()self:UpdateAllAppearance()end)
        end
    end

    local soulboundSetting=Settings.RegisterAddOnSetting(appearance,
        "LootLiquidator_showSoulboundVendorBadge","showSoulboundVendorBadge",
        self.db,"boolean","Show V on soulbound gear",false)
    if soulboundSetting.SetValueChangedCallback then
        soulboundSetting:SetValueChangedCallback(function() self:UpdateAllAppearance() end)
    end

    local tooltips,ttLayout=Settings.RegisterVerticalLayoutSubcategory(general,"Tooltips")
    Settings.RegisterAddOnCategory(tooltips)
    if Settings.CreatePanelInitializer and ttLayout and ttLayout.AddInitializer then
        ttLayout:AddInitializer(Settings.CreatePanelInitializer("LootLiquidatorTooltipPreviewTemplate",{}))
    end
    Section(ttLayout,"What to display")
    Checkbox(tooltips,"showTooltips","Show Loot Liquidator tooltips",
        "Hide or show Loot Liquidator's extra tooltip lines, without changing recommendations.",true)
    Dropdown(tooltips,"tooltipDetail","Tooltip detail",
        "Minimal shows the recommended action; Summary shows key prices; Detailed shows materials and known profession progression. Extra research notes are optional.",
        {{1,"Minimal — recommendation only"},{2,"Summary — main prices"},
         {3,"Detailed — materials and professions"}},2)
    Checkbox(tooltips,"tooltipAuction","Show auction estimate",
        "Show the original item's estimated auction value in Summary or Detailed tooltips.",true)
    Checkbox(tooltips,"tooltipVendor","Show vendor value",
        "Show the guaranteed vendor price in Summary or Detailed tooltips.",true)
    Checkbox(tooltips,"showUnavailableConversions","Show unavailable processing estimates",
        "Show possible processing values even when no eligible character is known; these never win a recommendation.",true)
    Checkbox(tooltips,"showFallback","Show next-best action with Auction",
        "When Auction wins, show the next best available action in parentheses, such as Auction (Disenchant).",true)
    Section(ttLayout,"Gear token and exchange information")
    Checkbox(tooltips,"showATTTokenSummary","Show gear token exchange table",
        "Show class-specific gear token rewards, missing appearances and available redemption choices. Hiding this does not change recommendations.",true)
    Section(ttLayout,"Detailed tooltip content")
    Checkbox(tooltips,"showMaterialBreakdown","Show processing materials",
        "In Detailed mode, show a concise table of estimated material yields.",true)
    Checkbox(tooltips,"showResearchDetails","Show notes",
        "Show optional research explanations, yield evidence, and token exchange notes. Core prices, materials and important warnings are always visible.",false)
    Section(ttLayout,"Optional profession information")
    Checkbox(tooltips,"showProfessionHints","Show profession alternatives",
        "Describe relevant profession processing options without overriding gold recommendations.",false)
    Checkbox(tooltips,"showAltHints","Show known alt characters",
        "Include eligible scanned alts with profession hints; enable profession alternatives as well.",false)
    Checkbox(tooltips,"showDisenchantStatus","Show disenchant eligibility notes",
        "Explain why gear that looks disenchantable did not receive a Disenchant recommendation.",false)
    -- Hover-preview is intentionally at the top of this same page. No extra
    -- Tooltips subcategory or tall static preview remains.

    local rules,ruleLayout=Settings.RegisterVerticalLayoutSubcategory(general,"Pricing & Actions")
    Settings.RegisterAddOnCategory(rules)
    Section(ruleLayout,"Auction pricing")
    Checkbox(rules,"tooltipShowAfterAHCut","Deduct 5% auction-house cut",
        "VALUATION: Compare and show auction and processed-material proceeds after the AH cut. Turning off changes both displayed values and recommendations.",true)
    -- Reagents automatically use TSM lowest listing with market-average fallback;
    -- the old reagentMatchLowest checkbox was functionally a no-op.
    Section(ruleLayout,"Required extra profit (gold)")
    Slider(rules,"minConversionExtraGold","Minimum processing profit",
        "Extra net gold required over an unprocessed alternative before recommending processing the stack.",0,100,.05,0)
    Slider(rules,"minReagentProfitGold","Minimum reagent auction profit",
        "Extra net gold over vendoring the stack required before recommending a reagent auction.",0,100,.05,0)
    Slider(rules,"minGearProfitGold","Minimum gear auction profit",
        "Extra net gold over vendoring equipment required before an auction recommendation.",0,100,.05,0)

    local chars=self.RegisterNativeRosterTable and self:RegisterNativeRosterTable(general)

    local research,researchLayout=Settings.RegisterVerticalLayoutSubcategory(general,"Processing Research")
    Settings.RegisterAddOnCategory(research)
    Section(researchLayout,"Record actual results")
    Checkbox(research,"recordDisenchants","Record disenchant results",
        "Record reliably matched disenchant yields to account-wide SavedVariables.",true)
    Checkbox(research,"recordConversions","Record other processing results",
        "Record reliably matched milling, prospecting and supported single-input craft results.",true)
    Checkbox(research,"showProcessingSamples","Show sample counts in tooltips",
        "Show how many personal observations are available. Full distributions also require Detailed tooltips.",true)
    Section(researchLayout,"Which yield data to use for valuations")
    Dropdown(research,"disenchantDataMode","Disenchant yields",
        "Automatic favors personal results once reliable; Personal Only excludes external yield estimates; Reference Only ignores personal results for prices.",
        {{1,"Automatic"},{2,"Personal observations only"},{3,"Reference / TSM only"}},1)
    Dropdown(research,"millingDataMode","Milling yields",
        "Controls whether Milling prices use personal observations or reference estimates.",
        {{1,"Automatic"},{2,"Personal observations only"},{3,"Reference / TSM only"}},1)
    Dropdown(research,"prospectingDataMode","Prospecting yields",
        "Controls whether Prospecting prices use personal observations or reference estimates.",
        {{1,"Automatic"},{2,"Personal observations only"},{3,"Reference / TSM only"}},1)
    Dropdown(research,"otherConversionDataMode","Other processing yields",
        "Applies to one-input recipes. Vendor exchanges and on-use combine/split actions remain documented exchanges.",
        {{1,"Automatic"},{2,"Personal observations only"},{3,"Reference / recipe only"}},1)
    Section(researchLayout,"Skill-aware processing estimates")
    Checkbox(research,"skillAwareProcessing","Use character-specific processing research",
        "Use observed profession skill and equipment where available. A manually checked character with unknown skill uses the documented minimum recipe skill, with no assumed specialization or gear bonuses. Without a compatible research model, retain the selected fallback.",true)
    Dropdown(research,"processingFallbackMode","Processing Research Model",
        "Automatic blends matching built-in yields with compatible personal results. The influence of personal observations grows with effective sample count. Built-in Only excludes personal results; Personal Only requires observations. Per-method selection overrides this setting.",
        {{1,"Automatic (Recommended)"},
         {2,"Built-in Research Only"},
         {3,"Personal Research Only"}},1)
    Section(researchLayout,"Midnight prospecting: low/high estimate")
    Slider(research,"midnightProspectingUpgradePct","Midnight prospecting upgrade (%)",
        "0% uses the basic/low research values. 100% uses best-available upgraded yield estimates for each ore and material. Intermediate positions are APPROXIMATE, not Blizzard's skill formula. Diamond unlocks are separate.",0,100,5,0)
    Checkbox(research,"midnightDiamondCopper","Copper Consumer: diamond unlocked",
        "Enable only if your selected Jewelcrafter has the Refulgent Copper diamond specialization.",false)
    Checkbox(research,"midnightDiamondTin","Tin-vestigator: diamond unlocked",
        "Enable only if your selected Jewelcrafter has the Umbral Tin diamond specialization.",false)
    Checkbox(research,"midnightDiamondSilver","Silver Scrapper: diamond unlocked",
        "Enable only if your selected Jewelcrafter has the Brilliant Silver diamond specialization.",false)
    Checkbox(research,"midnightDiamondThorium","Thorium Thresher: diamond unlocked",
        "Enable only if your selected Jewelcrafter has the Dazzling Thorium diamond specialization.",false)
    Section(researchLayout,"Dragonflight prospecting: estimated low/high")
    Slider(research,"dragonflightProspectingUpgradePct","Dragonflight yield upgrade (%)",
        "0% uses historical TSM low estimates; 100% uses observed R3 Serevite and transferred ratios for other ores. Not Blizzard's exact formula.",0,100,5,0)
    Dropdown(research,"dragonflightProspectingOutputRank","Dragonflight output gem quality",
        "Automatic uses live Blizzard craft quality if known, otherwise conservative Rank 1. Ore quality is NOT automatically the resulting gem rank. Higher output ranks require actual effective skill or Inspiration.",
        {{0,"Automatic / conservative"},{1,"Gem Rank 1"},{2,"Gem Rank 2"},{3,"Gem Rank 3"}},0)
    Slider(research,"dragonflightProspectingInspirationPct","Dragonflight Inspiration chance (%)",
        "Only redistributes gem yield between ranks IF the following threshold toggle is enabled. Inspiration does not create extra gems.",0,60,1,0)
    Checkbox(research,"dragonflightProspectingInspirationCrossesThreshold","Inspiration raises gem rank",
        "Check ONLY if effective Inspiration pushes the recipe into the next quality rank; otherwise the Inspiration chance has no output-quality effect.",false)
    Slider(research,"dragonflightProspectingResourcefulnessPct","Dragonflight Resourcefulness chance (%)",
        "Rough input savings: each Resourcefulness proc assumed to save 30% of 5 ore, separate from gem quantity. Set to 0% for unupgraded fallback.",0,50,1,0)
    Checkbox(research,"dragonflightProspectingPrismaticUnlocked","Prospecting talent: Prismatic Ore unlocked",
        "Only with the Prospecting specialization. Soulbound Prismatic Ore is converted to modeled downstream materials, never valued at AH prices directly.",false)
    Section(researchLayout,"The War Within prospecting: low / high")
    Slider(research,"warWithinProspectingUpgradePct","TWW prospecting upgrade (%)",
        "0% = Q2 published-player reference/proxy low; 100% = ore-specific modeled higher yields. Changes both material EV and tooltip occurrence/ranges. No diamond unlocks are inferred.",0,100,5,0)
    Section(researchLayout,"Milling: expansion-specific low / high")
    Slider(research,"dragonflightMillingUpgradePct","Dragonflight milling upgrade (%)",
        "0% = original TSM per-herb output expectation; 100% = estimated improved yield. Tooltip probability and ranges follow the same setting.",0,100,5,0)
    Slider(research,"warWithinMillingUpgradePct","The War Within milling upgrade (%)",
        "A 2024 player reference reports ~12 pigments per 10 herbs; the low 10 and high 12 expected quantities are modeled scenarios. Display ranges are tooltip-only. Output quality is chosen conservatively.",0,100,5,0)
    Dropdown(research,"warWithinMillingOutputRank","TWW pigment output quality",
        "Auto conservatively prices the pigment rank matching the herb rank. Override only when profession skill supports the selected rank.",
        {{0,"Auto / input quality"},{1,"Pigment Rank 1"},{2,"Pigment Rank 2"},{3,"Pigment Rank 3"}},0)
    Slider(research,"midnightMillingUpgradePct","Midnight milling upgrade (%)",
        "Low/high expected pigment counts are provisional; only researched herb -> pigment mappings are used. Zero is the same low fallback used for pricing.",0,100,5,0)
    Section(researchLayout,"Disenchanting: expansion-specific low / high")
    Slider(research,"dragonflightDisenchantUpgradePct","Dragonflight disenchant upgrade (%)",
        "0% = the existing source-specific reference or conservative missing-data profile; higher settings gradually increase modeled quantities, occurrence proxies and yield ranges.",0,100,5,0)
    Slider(research,"warWithinDisenchantUpgradePct","The War Within disenchant upgrade (%)",
        "0% = the same source-specific low reference; increasing skill upgrades changes expected quantity and tooltip probability/yield estimates together.",0,100,5,0)
    Slider(research,"midnightDisenchantUpgradePct","Midnight disenchant upgrade (%)",
        "0% = original observed reference with a conservative missing-data substitute where necessary; high scenario is modeled, not a guaranteed skill formula.",0,100,5,0)
    Section(researchLayout,"Confidence thresholds")
    Slider(research,"researchSkillTolerance","Skill matching tolerance (+/-)",
        "Borrow compatible observations from nearby profession skill levels. Zero means exact skill only.",0,40,1,10)
    Slider(research,"minPersonalSamples","Minimum weighted samples",
        "Minimum effective samples required before personal observations drive recommendations.",1,100,1,30)

    -- Standard integrations use Blizzard's vertical Settings controls and
    -- button initializers rather than a hand-drawn canvas of checkboxes.
    local integrations,integrationsLayout=Settings.RegisterVerticalLayoutSubcategory(general,"Integrations")
    Settings.RegisterAddOnCategory(integrations)
    Section(integrationsLayout,"Connected addons")
    Checkbox(integrations,"enableTSMIntegration","TradeSkillMaster pricing",
        "Read TSM auction pricing and operations without changing your TSM profile.",true)
    Checkbox(integrations,"enableATTIntegration","Legacy ATT token lookup (temporary)",
        "Fallback while direct token data is researched. ATT relationships never supply crafting yields.",true)
    Section(integrationsLayout,"Independent token research")
    Checkbox(integrations,"collectTokenResearch","Record direct token rewards and exchanges",
        "Passively record item-token vendor offers and directly opened equipment rewards as research candidates. No crafting outputs, no ATT dependency, and no automatic changes to valuations.",true)
    if CreateSettingsButtonInitializer and integrationsLayout.AddInitializer then
        integrationsLayout:AddInitializer(CreateSettingsButtonInitializer(
            "Token research observations","View / copy research export",function()
                if LL.TokenResearchExport and LL.ShowCopy then
                    LL:ShowCopy("Direct token observations - page 1",LL:TokenResearchExport(1))
                end
            end,"Copy direct equipment token relationships. Additional pages: /ll tokenexport 2 (etc.).",false))
    end
    TSMDropdown(integrations,"tsmFallbackOperation","TSM operation for ungrouped items")
    if CreateSettingsButtonInitializer and integrationsLayout.AddInitializer then
        integrationsLayout:AddInitializer(CreateSettingsButtonInitializer(
            "Legacy cache (research only)","Import filtered ATT cache",function()
                if LL.ImportLegacyTokenCandidates then
                    local count,skipped=LL:ImportLegacyTokenCandidates()
                    if print then print(("Loot Liquidator: %d unverified ATT relationships copied to research; %d excluded. No valuation data changed."):
                        format(count or 0,skipped or 0)) end
                end
            end,"Reads stored ATT records only. Excludes crafting reagents and non-equipment rewards. Copy via token research export for verification.",false))
    end
    Section(integrationsLayout,"ATT reward cache")
    if CreateSettingsButtonInitializer and integrationsLayout.AddInitializer then
        integrationsLayout:AddInitializer(CreateSettingsButtonInitializer(
            "Update ATT cache","Update ATT Cache",function()
                if LL.StartATTCacheUpdate then
                    local ok,msg=LL:StartATTCacheUpdate()
                    if not ok and print then print("Loot Liquidator: "..tostring(msg)) end
                end
                if LL.RefreshATTCacheUI then LL.RefreshATTCacheUI() end
            end,"Refresh cached ATT reward relationships.",false))
    end
    Section(integrationsLayout,"TSM recommended setup")
    if CreateSettingsButtonInitializer and integrationsLayout.AddInitializer then
        integrationsLayout:AddInitializer(CreateSettingsButtonInitializer(
            "Recommended TSM setup","Select / copy TSM export",function()
                if LL.ShowCopy and LL.RecommendedTSMSetupText then
                    LL:ShowCopy("Recommended TSM Setup",LL:RecommendedTSMSetupText())
                end
            end,"Opens selectable text. Press Ctrl+C in WoW, then paste into TSM. Does not modify TSM.",false))
    end

    if self.CreateItemIgnorePanel then
        local ignores=Settings.RegisterCanvasLayoutSubcategory(general,
            self:CreateItemIgnorePanel(),"Ignored Items")
        Settings.RegisterAddOnCategory(ignores)
    end
    self.settingsPages={general=general,tooltips=tooltips,research=research,
        appearance=appearance,rules=rules,chars=chars,integrations=integrations}

end
function LL:OpenSettings()
    if not self.settingsCategory then self:RegisterNativeSettings() end
    if Settings and Settings.OpenToCategory and self.settingsCategory then
        Settings.OpenToCategory(self.settingsCategory:GetID())
    end
end
local init=CreateFrame("Frame")
init:RegisterEvent("PLAYER_LOGIN")
init:SetScript("OnEvent",function()
    if LL.db then LL:RegisterNativeSettings() end
end)
